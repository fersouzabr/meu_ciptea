import 'package:flutter_test/flutter_test.dart';
import 'package:minha_ciptea/main.dart';
void main(){testWidgets('abre onboarding',(tester) async {await tester.pumpWidget(const MinhaCipteaApp());expect(find.text('Guarde sua CIPTEA\ncom segurança'),findsOneWidget);});}
