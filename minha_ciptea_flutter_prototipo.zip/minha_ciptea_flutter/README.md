# Minha CIPTEA - protótipo Flutter

Protótipo visual navegável baseado nas telas aprovadas.

## Executar

1. Instale Flutter 3.24 ou superior e Android Studio.
2. Na pasta do projeto, execute:

```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

## O que está funcional

- Onboarding em 3 etapas
- Tema claro/escuro
- Navegação inferior
- Seleção de PDF com `file_picker`
- Fluxo de detalhes e confirmação
- Visualizador demonstrativo
- Modais, privacidade e informações legais

## Importante

Este pacote é um protótipo de interface. A criptografia AES-256-GCM, Android Keystore, biometria real, armazenamento privado do PDF, leitura do PDF e QR Code devem ser implementados antes de uso em produção.
