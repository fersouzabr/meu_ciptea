import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MinhaCipteaApp());

class AppColors {
  static const purple = Color(0xFF6D28D9);
  static const purple2 = Color(0xFF8B5CF6);
  static const lightBg = Color(0xFFF8F7FC);
  static const darkBg = Color(0xFF111018);
  static const success = Color(0xFF22B573);
}

class MinhaCipteaApp extends StatefulWidget {
  const MinhaCipteaApp({super.key});
  @override State<MinhaCipteaApp> createState() => _MinhaCipteaAppState();
}
class _MinhaCipteaAppState extends State<MinhaCipteaApp> {
  ThemeMode mode = ThemeMode.light;
  void toggleTheme() => setState(() => mode = mode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light);
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Minha CIPTEA',
    themeMode: mode,
    theme: _theme(Brightness.light),
    darkTheme: _theme(Brightness.dark),
    home: OnboardingPage(onFinish: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomePage(onToggleTheme: toggleTheme)))),
  );
  ThemeData _theme(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: AppColors.purple, brightness: brightness, surface: dark ? const Color(0xFF191722) : Colors.white);
    return ThemeData(
      useMaterial3: true, brightness: brightness, colorScheme: scheme,
      scaffoldBackgroundColor: dark ? AppColors.darkBg : AppColors.lightBg,
      fontFamily: 'Roboto',
      cardTheme: CardThemeData(elevation: 0, color: dark ? const Color(0xFF201D2B) : Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: dark ? const Color(0xFF211E2B) : Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
    );
  }
}

class PrimaryButton extends StatelessWidget {
  final String label; final VoidCallback onPressed; final IconData? icon;
  const PrimaryButton(this.label,{super.key,required this.onPressed,this.icon});
  @override Widget build(BuildContext context) => SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(
    onPressed:onPressed, icon: icon == null ? const SizedBox.shrink() : Icon(icon), label: Text(label, style: const TextStyle(fontSize:16,fontWeight:FontWeight.w700)),
    style: FilledButton.styleFrom(backgroundColor:AppColors.purple,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16))),
  ));
}

class LogoMark extends StatelessWidget {
  final double size; const LogoMark({super.key,this.size=70});
  @override Widget build(BuildContext context) => Container(width:size,height:size,decoration:BoxDecoration(shape:BoxShape.circle,gradient:const LinearGradient(colors:[AppColors.purple2,AppColors.purple])),child:Icon(Icons.favorite_rounded,color:Colors.white,size:size*.52));
}

class OnboardingPage extends StatefulWidget {
  final VoidCallback onFinish; const OnboardingPage({super.key,required this.onFinish});
  @override State<OnboardingPage> createState()=>_OnboardingPageState();
}
class _OnboardingPageState extends State<OnboardingPage>{
  final controller=PageController(); int index=0;
  final pages=const [
    (Icons.folder_special_rounded,'Guarde sua CIPTEA\ncom segurança','Tenha seus documentos sempre à mão, no seu celular, com privacidade e praticidade.'),
    (Icons.phone_android_rounded,'Acesse mesmo\nsem internet','Seus documentos ficam salvos de forma segura no aparelho, para você acessar quando precisar.'),
    (Icons.shield_rounded,'Sua privacidade\nem primeiro lugar','Seus documentos ficam apenas no celular. Você mantém o controle sobre tudo.'),
  ];
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Column(children:[
    Align(alignment:Alignment.centerRight,child:TextButton(onPressed:widget.onFinish,child:const Text('Pular'))),
    Expanded(child:PageView.builder(controller:controller,itemCount:pages.length,onPageChanged:(v)=>setState(()=>index=v),itemBuilder:(c,i){final p=pages[i];return Padding(padding:const EdgeInsets.fromLTRB(28,20,28,8),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      Container(width:190,height:190,decoration:BoxDecoration(color:AppColors.purple.withOpacity(.1),shape:BoxShape.circle),child:Icon(p.$1,size:92,color:AppColors.purple)),
      const SizedBox(height:42),Text(p.$2,textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.w800,height:1.1)),
      const SizedBox(height:18),Text(p.$3,textAlign:TextAlign.center,style:Theme.of(context).textTheme.bodyLarge?.copyWith(height:1.5,color:Theme.of(context).colorScheme.onSurfaceVariant)),
    ]));})),
    Row(mainAxisAlignment:MainAxisAlignment.center,children:List.generate(3,(i)=>AnimatedContainer(duration:const Duration(milliseconds:250),margin:const EdgeInsets.all(4),width:i==index?24:8,height:8,decoration:BoxDecoration(color:i==index?AppColors.purple:AppColors.purple.withOpacity(.2),borderRadius:BorderRadius.circular(12))))),
    Padding(padding:const EdgeInsets.all(24),child:Column(children:[PrimaryButton(index==2?'Começar':'Próximo',onPressed:(){if(index==2){widget.onFinish();}else{controller.nextPage(duration:const Duration(milliseconds:350),curve:Curves.easeOut);}}),if(index==2)TextButton(onPressed:()=>showLegal(context),child:const Text('Conhecer a privacidade'))])),
  ])));
}

class HomePage extends StatefulWidget {final VoidCallback onToggleTheme;const HomePage({super.key,required this.onToggleTheme});@override State<HomePage> createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{int current=0; bool hasDocument=true;
  @override Widget build(BuildContext context)=>Scaffold(
    body:SafeArea(child:IndexedStack(index:current,children:[_home(),DocumentsPage(hasDocument:hasDocument,onOpen:()=>openViewer(context)),PrivacyPage(),MorePage(onToggleTheme:widget.onToggleTheme)])),
    bottomNavigationBar:NavigationBar(selectedIndex:current,onDestinationSelected:(v)=>setState(()=>current=v),destinations:const[
      NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home_rounded),label:'Início'),NavigationDestination(icon:Icon(Icons.description_outlined),label:'Documentos'),NavigationDestination(icon:Icon(Icons.shield_outlined),label:'Privacidade'),NavigationDestination(icon:Icon(Icons.more_horiz),label:'Mais')]),
    floatingActionButton:current==0?FloatingActionButton.extended(onPressed:()=>addDocument(context),backgroundColor:AppColors.purple,foregroundColor:Colors.white,icon:const Icon(Icons.add),label:const Text('Adicionar CIPTEA')):null,
  );
  Widget _home()=>ListView(padding:const EdgeInsets.fromLTRB(20,20,20,100),children:[
    Row(children:[const CircleAvatar(radius:24,backgroundColor:Color(0xFFE8DFFF),child:Icon(Icons.person,color:AppColors.purple)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Boa tarde,',style:Theme.of(context).textTheme.bodyMedium),Text('Fernando',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w800))])),IconButton(onPressed:()=>setState(()=>current=3),icon:const Icon(Icons.settings_outlined))]),
    const SizedBox(height:24),Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:LinearGradient(colors:[AppColors.purple.withOpacity(.13),AppColors.purple2.withOpacity(.06)]),borderRadius:BorderRadius.circular(24)),child:const Row(children:[Expanded(child:Text('Mais respeito\nMais inclusão\nMais oportunidades',style:TextStyle(fontSize:18,height:1.45,fontWeight:FontWeight.w700))),Icon(Icons.favorite_border_rounded,color:AppColors.purple,size:34)])),
    const SizedBox(height:28),Row(children:[Expanded(child:Text('Suas carteiras',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w800))),TextButton(onPressed:()=>setState(()=>current=1),child:const Text('Ver todas'))]),
    const SizedBox(height:10),DocumentCard(onTap:()=>openViewer(context)),const SizedBox(height:18),
    OutlinedButton.icon(onPressed:()=>addDocument(context),icon:const Icon(Icons.add),label:const Text('Adicionar CIPTEA'),style:OutlinedButton.styleFrom(minimumSize:const Size.fromHeight(64),side:const BorderSide(color:AppColors.purple,style:BorderStyle.solid),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))))
  ]);
  Future<void> addDocument(BuildContext context) async {final saved=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>const AddDocumentPage()));if(saved==true)setState(()=>hasDocument=true);}
  void openViewer(BuildContext context)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ViewerPage()));
}

class DocumentCard extends StatelessWidget{final VoidCallback onTap;const DocumentCard({super.key,required this.onTap});@override Widget build(BuildContext context)=>Card(child:InkWell(borderRadius:BorderRadius.circular(22),onTap:onTap,child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[
  Container(width:64,height:82,decoration:BoxDecoration(color:const Color(0xFFF1ECFF),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.badge_outlined,color:AppColors.purple,size:36)),const SizedBox(width:16),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('CIPTEA',style:TextStyle(fontWeight:FontWeight.w800,fontSize:17)),const Text('Gabriel',style:TextStyle(fontSize:16)),const SizedBox(height:8),Text('Adicionado em 17/11/2026',style:TextStyle(fontSize:12,color:Theme.of(context).colorScheme.onSurfaceVariant))])),const CircleAvatar(backgroundColor:Color(0xFFECE4FF),child:Icon(Icons.arrow_forward,color:AppColors.purple))]))));}

class AddDocumentPage extends StatefulWidget{const AddDocumentPage({super.key});@override State<AddDocumentPage> createState()=>_AddDocumentPageState();}
class _AddDocumentPageState extends State<AddDocumentPage>{String? fileName;final name=TextEditingController(text:'CIPTEA do Gabriel');bool biometric=true;int step=0;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(step==0?'Adicionar CIPTEA':'Detalhes do documento')),body:ListView(padding:const EdgeInsets.all(24),children:step==0?_select():_details());
  List<Widget> _select()=>[const SizedBox(height:30),Container(height:190,decoration:BoxDecoration(color:AppColors.purple.withOpacity(.08),shape:BoxShape.circle),child:const Icon(Icons.picture_as_pdf_rounded,size:96,color:AppColors.purple)),const SizedBox(height:30),Text('Selecione o seu documento',textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:12),Text('Escolha o arquivo PDF da sua CIPTEA emitido pelo órgão responsável.',textAlign:TextAlign.center,style:Theme.of(context).textTheme.bodyLarge),const SizedBox(height:28),PrimaryButton(fileName??'Selecionar PDF',icon:Icons.upload_file,onPressed:()async{final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['pdf']);if(r!=null)setState((){fileName=r.files.single.name;step=1;});}),const SizedBox(height:20),const InfoBox(texto:'O aplicativo armazenará uma cópia do documento original. Ele não modifica, emite ou valida a CIPTEA.')];
  List<Widget> _details()=>[Container(height:180,decoration:BoxDecoration(color:const Color(0xFFF0EBFF),borderRadius:BorderRadius.circular(20)),child:const Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.badge_rounded,size:70,color:AppColors.purple),Text('PRÉ-VISUALIZAÇÃO DO PDF',style:TextStyle(color:AppColors.purple,fontWeight:FontWeight.w800))])),const SizedBox(height:24),TextField(controller:name,decoration:const InputDecoration(labelText:'Nome para identificar')),const SizedBox(height:22),Text('Proteção adicional',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w800)),SwitchListTile(value:biometric,onChanged:(v)=>setState(()=>biometric=v),secondary:const Icon(Icons.fingerprint,color:AppColors.purple),title:const Text('Exigir biometria para abrir'),contentPadding:EdgeInsets.zero),const SizedBox(height:28),PrimaryButton('Salvar documento',onPressed:()async{final p=await SharedPreferences.getInstance();await p.setBool('hasDocument',true);if(!mounted)return;Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const SuccessPage()));})];
}

class InfoBox extends StatelessWidget{final String texto;const InfoBox({super.key,required this.texto});@override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:AppColors.purple.withOpacity(.08),borderRadius:BorderRadius.circular(16)),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.info_outline,color:AppColors.purple),const SizedBox(width:12),Expanded(child:Text(texto,style:const TextStyle(height:1.4)))]));}

class SuccessPage extends StatelessWidget{const SuccessPage({super.key});@override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const CircleAvatar(radius:58,backgroundColor:Color(0xFFE1F8ED),child:Icon(Icons.check_rounded,size:72,color:AppColors.success)),const SizedBox(height:34),Text('Documento adicionado\ncom sucesso!',textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:14),const Text('Sua CIPTEA já está salva no celular de forma segura.',textAlign:TextAlign.center),const SizedBox(height:40),PrimaryButton('Ver minha carteira',onPressed:()=>Navigator.pop(context,true)),TextButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Adicionar outro documento'))]))));}

class ViewerPage extends StatelessWidget{const ViewerPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('CIPTEA do Gabriel'),actions:[IconButton(onPressed:()=>options(context),icon:const Icon(Icons.more_vert))]),body:Column(children:[Expanded(child:Container(margin:const EdgeInsets.all(18),padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),boxShadow:const [BoxShadow(color:Colors.black12,blurRadius:16)]),child:const Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text('CIPTEA',style:TextStyle(color:Colors.black,fontSize:28,fontWeight:FontWeight.w900)),Text('CARTEIRA DE IDENTIFICAÇÃO DA PESSOA COM TRANSTORNO DO ESPECTRO AUTISTA',style:TextStyle(color:Colors.black,fontSize:12,fontWeight:FontWeight.bold)),Divider(height:32),Row(children:[CircleAvatar(radius:38,child:Icon(Icons.person,size:44)),SizedBox(width:18),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('NOME',style:TextStyle(color:Colors.black54,fontSize:10)),Text('Gabriel Silva',style:TextStyle(color:Colors.black,fontSize:18,fontWeight:FontWeight.bold)),SizedBox(height:12),Text('VALIDADE',style:TextStyle(color:Colors.black54,fontSize:10)),Text('12/03/2028',style:TextStyle(color:Colors.black))]))]),Spacer(),Align(alignment:Alignment.bottomRight,child:Icon(Icons.qr_code_2,size:100,color:Colors.black))]))),Container(padding:const EdgeInsets.fromLTRB(20,8,20,20),child:Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_Action(Icons.share_outlined,'Compartilhar',(){}),_Action(Icons.open_in_new,'Abrir link',(){}),_Action(Icons.more_horiz,'Mais opções',()=>options(context))]))]));}
class _Action extends StatelessWidget{final IconData icon;final String label;final VoidCallback tap;const _Action(this.icon,this.label,this.tap);@override Widget build(BuildContext context)=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(12),child:Padding(padding:const EdgeInsets.all(8),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,color:AppColors.purple),const SizedBox(height:4),Text(label,style:const TextStyle(fontSize:12))])));}
void options(BuildContext context)=>showModalBottomSheet(context:context,showDragHandle:true,builder:(c)=>SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(8,0,8,20),child:Column(mainAxisSize:MainAxisSize.min,children:[const ListTile(title:Text('Mais opções',style:TextStyle(fontWeight:FontWeight.w800,fontSize:20))),for(final item in const [(Icons.share_outlined,'Compartilhar documento'),(Icons.qr_code_2,'Abrir link / QR Code'),(Icons.edit_outlined,'Renomear'),(Icons.info_outline,'Informações do documento'),(Icons.delete_outline,'Excluir documento')])ListTile(leading:Icon(item.$1,color:item.$2.startsWith('Excluir')?Colors.red:AppColors.purple),title:Text(item.$2),onTap:()=>Navigator.pop(c))])));

class DocumentsPage extends StatelessWidget{final bool hasDocument;final VoidCallback onOpen;const DocumentsPage({super.key,required this.hasDocument,required this.onOpen});@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[Text('Documentos',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:20),if(hasDocument)DocumentCard(onTap:onOpen)else const InfoBox(texto:'Você ainda não adicionou documentos.')]);}

class PrivacyPage extends StatefulWidget{const PrivacyPage({super.key});@override State<PrivacyPage> createState()=>_PrivacyPageState();}
class _PrivacyPageState extends State<PrivacyPage>{bool screen=true;@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[Text('Privacidade e segurança',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:20),const ListTile(leading:Icon(Icons.fingerprint,color:AppColors.purple),title:Text('Biometria'),subtitle:Text('Ativada'),trailing:Icon(Icons.chevron_right)),const Divider(),const ListTile(leading:Icon(Icons.lock_clock_outlined,color:AppColors.purple),title:Text('Bloqueio automático'),subtitle:Text('Após 2 minutos'),trailing:Icon(Icons.chevron_right)),const Divider(),SwitchListTile(value:screen,onChanged:(v)=>setState(()=>screen=v),secondary:const Icon(Icons.visibility_off_outlined,color:AppColors.purple),title:const Text('Impedir captura de tela'),subtitle:const Text('Mais proteção para seus documentos')),const Divider(),const ListTile(leading:Icon(Icons.pin_outlined,color:AppColors.purple),title:Text('PIN alternativo'),subtitle:Text('Configurar'),trailing:Icon(Icons.chevron_right)),const SizedBox(height:30),ListTile(leading:const Icon(Icons.delete_outline,color:Colors.red),title:const Text('Excluir todos os dados',style:TextStyle(color:Colors.red)),subtitle:const Text('Remove todos os documentos e ajustes'),onTap:()=>showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Excluir todos os dados?'),content:const Text('Esta ação não poderá ser desfeita.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('Excluir'))]))]);}

class MorePage extends StatelessWidget{final VoidCallback onToggleTheme;const MorePage({super.key,required this.onToggleTheme});@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[Text('Mais',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:18),ListTile(leading:const Icon(Icons.dark_mode_outlined,color:AppColors.purple),title:const Text('Alternar tema'),subtitle:const Text('Modo claro ou escuro'),onTap:onToggleTheme,trailing:const Icon(Icons.chevron_right)),ListTile(leading:const Icon(Icons.gavel_outlined,color:AppColors.purple),title:const Text('Informações legais'),onTap:()=>showLegal(context),trailing:const Icon(Icons.chevron_right)),const ListTile(leading:Icon(Icons.info_outline,color:AppColors.purple),title:Text('Sobre o aplicativo'),subtitle:Text('Versão 1.0.0'))]);}
void showLegal(BuildContext context)=>showModalBottomSheet(context:context,isScrollControlled:true,showDragHandle:true,builder:(c)=>DraggableScrollableSheet(expand:false,initialChildSize:.72,maxChildSize:.9,builder:(c,sc)=>ListView(controller:sc,padding:const EdgeInsets.all(24),children:[Text('Informações legais',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:18),const InfoBox(texto:'O Minha CIPTEA é um aplicativo privado e independente. Não possui vínculo com órgãos públicos e não emite, substitui ou valida documentos oficiais.'),const SizedBox(height:18),const Text('A autenticidade e a aceitação da CIPTEA dependem do órgão emissor e das normas aplicáveis em cada localidade.',style:TextStyle(height:1.5)),const SizedBox(height:20),const ListTile(leading:Icon(Icons.lock_outline,color:AppColors.purple),title:Text('Política de Privacidade'),trailing:Icon(Icons.chevron_right)),const ListTile(leading:Icon(Icons.description_outlined,color:AppColors.purple),title:Text('Termos de Uso'),trailing:Icon(Icons.chevron_right)),const ListTile(leading:Icon(Icons.info_outline,color:AppColors.purple),title:Text('Sobre o aplicativo'),subtitle:Text('Versão 1.0.0'))]));
