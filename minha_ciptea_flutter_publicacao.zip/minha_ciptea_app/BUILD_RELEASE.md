# Build e publicação Android

1. Instale Flutter estável com Android SDK 36 e Java 17.
2. Execute `flutter pub get`, `flutter analyze` e `flutter test`.
3. Gere a chave: `keytool -genkeypair -v -keystore ~/upload-keystore.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias upload`.
4. Copie `android/key.properties.example` para `android/key.properties` e preencha sem versionar.
5. Execute `flutter build appbundle --release`.
6. O AAB será criado em `build/app/outputs/bundle/release/app-release.aab`.

O applicationId definitivo é `br.com.minhaciptea.app`. Troque antes do primeiro envio se você não controlar esse identificador, pois ele não poderá ser alterado depois da publicação.
