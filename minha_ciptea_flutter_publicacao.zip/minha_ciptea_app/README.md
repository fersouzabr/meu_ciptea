# Minha CIPTEA

Aplicativo Flutter local-first para armazenar PDFs CIPTEA no Android.

## Implementado
- PDF real via seletor do Android
- validação do cabeçalho `%PDF`
- criptografia AES-256-GCM
- chave no Android Keystore via `flutter_secure_storage`
- armazenamento privado e offline
- múltiplos documentos
- visualizador PDF com zoom
- autenticação biométrica ou credencial do aparelho
- bloqueio automático
- proteção contra captura/gravação de tela
- compartilhamento temporário controlado
- renomear e excluir
- exclusão integral
- scanner de QR Code com abertura externa de links
- modo claro/escuro e onboarding

## Compilar
Requer Flutter estável e Android Studio:
```bash
flutter create . --platforms=android --org br.com.minhaciptea
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```
Depois do `flutter create`, preserve os arquivos `lib/`, `pubspec.yaml` e as alterações Android deste pacote.

## Segurança
O PDF descriptografado só é criado temporariamente para leitura/compartilhamento e é apagado ao fechar o visualizador. Android backups estão desativados. Para publicação, faça revisão de segurança, teste em aparelhos reais e auditoria jurídica/LGPD.
