import 'package:flutter_test/flutter_test.dart';
import 'package:minha_ciptea/main.dart';
void main() {
  testWidgets('abre o aplicativo', (tester) async {
    await tester.pumpWidget(const MinhaCipteaApp());
    await tester.pumpAndSettle();
    expect(find.text('Minha CIPTEA'), findsWidgets);
  });
}
