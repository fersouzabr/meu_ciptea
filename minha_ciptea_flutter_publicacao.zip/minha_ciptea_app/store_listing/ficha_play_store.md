# Minha CIPTEA

## Descrição curta
Guarde e acesse localmente o PDF da sua CIPTEA com proteção e privacidade.

## Aviso
Aplicativo privado e independente. Não possui vínculo com órgãos públicos, não emite, substitui ou valida documentos oficiais.

## Categoria sugerida
Ferramentas

## Declaração de dados
- Documentos: armazenados localmente e criptografados; não enviados ao desenvolvedor.
- Câmera: usada sob demanda para QR Code; imagens não são armazenadas.
- Biometria: autenticada pelo Android; nenhum dado biométrico é acessado pelo app.
- Sem conta, anúncios ou analytics.

## Pendências do publicador
- Hospedar politica_privacidade.html em URL pública HTTPS.
- Informar e-mail de suporte e nome legal do desenvolvedor.
- Produzir ícone 512x512, feature graphic 1024x500 e capturas de tela reais.
- Preencher Segurança dos dados e declaração de app de saúde no Play Console.
