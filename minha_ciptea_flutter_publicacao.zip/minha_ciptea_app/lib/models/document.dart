class CipteaDocument {
  final String id, name, encryptedPath, originalName;
  final DateTime createdAt;
  final bool biometric;
  const CipteaDocument({required this.id,required this.name,required this.encryptedPath,required this.originalName,required this.createdAt,required this.biometric});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'encryptedPath':encryptedPath,'originalName':originalName,'createdAt':createdAt.toIso8601String(),'biometric':biometric};
  factory CipteaDocument.fromJson(Map<String,dynamic> j)=>CipteaDocument(id:j['id'],name:j['name'],encryptedPath:j['encryptedPath'],originalName:j['originalName'],createdAt:DateTime.parse(j['createdAt']),biometric:j['biometric']??true);
  CipteaDocument copyWith({String? name,bool? biometric})=>CipteaDocument(id:id,name:name??this.name,encryptedPath:encryptedPath,originalName:originalName,createdAt:createdAt,biometric:biometric??this.biometric);
}
