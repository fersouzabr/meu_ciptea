import 'package:shared_preferences/shared_preferences.dart';
class SettingsService {
 static const _theme='darkMode',_screen='screenProtection',_lock='lockMinutes',_onboarding='onboarding';
 Future<bool> dark()=>SharedPreferences.getInstance().then((p)=>p.getBool(_theme)??false);
 Future<void> setDark(bool v)=>SharedPreferences.getInstance().then((p)=>p.setBool(_theme,v));
 Future<bool> screenProtection()=>SharedPreferences.getInstance().then((p)=>p.getBool(_screen)??true);
 Future<void> setScreenProtection(bool v)=>SharedPreferences.getInstance().then((p)=>p.setBool(_screen,v));
 Future<int> lockMinutes()=>SharedPreferences.getInstance().then((p)=>p.getInt(_lock)??2);
 Future<void> setLockMinutes(int v)=>SharedPreferences.getInstance().then((p)=>p.setInt(_lock,v));
 Future<bool> onboardingDone()=>SharedPreferences.getInstance().then((p)=>p.getBool(_onboarding)??false);
 Future<void> finishOnboarding()=>SharedPreferences.getInstance().then((p)=>p.setBool(_onboarding,true));
}
