import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/document.dart';

class VaultService {
 static const _storage=FlutterSecureStorage(aOptions:AndroidOptions(encryptedSharedPreferences:true));
 static const _keyName='vault_master_key_v1', _docsKey='ciptea_documents_v1';
 final _cipher=AesGcm.with256bits();
 Future<SecretKey> _key() async {var raw=await _storage.read(key:_keyName); if(raw==null){final bytes=await _cipher.newSecretKey().then((k)=>k.extractBytes());raw=base64Encode(bytes);await _storage.write(key:_keyName,value:raw);}return SecretKey(base64Decode(raw));}
 Future<List<CipteaDocument>> list() async {final p=await SharedPreferences.getInstance();final raw=p.getString(_docsKey);if(raw==null)return [];return (jsonDecode(raw) as List).map((e)=>CipteaDocument.fromJson(Map<String,dynamic>.from(e))).toList()..sort((a,b)=>b.createdAt.compareTo(a.createdAt));}
 Future<void> _saveList(List<CipteaDocument> docs) async {final p=await SharedPreferences.getInstance();await p.setString(_docsKey,jsonEncode(docs.map((e)=>e.toJson()).toList()));}
 Future<CipteaDocument> importPdf({required String sourcePath,required String name,required String originalName,required bool biometric}) async {
  final bytes=await File(sourcePath).readAsBytes(); if(bytes.length<5||String.fromCharCodes(bytes.take(4))!='%PDF')throw const FormatException('O arquivo selecionado não é um PDF válido.');
  final box=await _cipher.encrypt(bytes,secretKey:await _key());final dir=Directory('${(await getApplicationSupportDirectory()).path}/vault');await dir.create(recursive:true);final id=const Uuid().v4();
  final out=File('${dir.path}/$id.ciptea');final payload=BytesBuilder()..add(box.nonce)..add(box.mac.bytes)..add(box.cipherText);await out.writeAsBytes(payload.toBytes(),flush:true);
  final doc=CipteaDocument(id:id,name:name,encryptedPath:out.path,originalName:originalName,createdAt:DateTime.now(),biometric:biometric);final docs=await list()..add(doc);await _saveList(docs);return doc;
 }
 Future<Uint8List> decrypt(CipteaDocument d) async {final b=await File(d.encryptedPath).readAsBytes();if(b.length<28)throw const FormatException('Documento criptografado inválido.');final box=SecretBox(b.sublist(28),nonce:b.sublist(0,12),mac:Mac(b.sublist(12,28)));return Uint8List.fromList(await _cipher.decrypt(box,secretKey:await _key()));}
 Future<File> temporaryPdf(CipteaDocument d) async {final dir=await getTemporaryDirectory();final f=File('${dir.path}/${d.id}.pdf');return f.writeAsBytes(await decrypt(d),flush:true);}
 Future<void> delete(CipteaDocument d) async {final f=File(d.encryptedPath);if(await f.exists())await f.delete();final docs=await list()..removeWhere((x)=>x.id==d.id);await _saveList(docs);}
 Future<void> rename(CipteaDocument d,String name) async {final docs=await list();final i=docs.indexWhere((x)=>x.id==d.id);if(i>=0){docs[i]=d.copyWith(name:name);await _saveList(docs);}}
 Future<void> deleteAll() async {for(final d in await list()){final f=File(d.encryptedPath);if(await f.exists())await f.delete();}final p=await SharedPreferences.getInstance();await p.remove(_docsKey);await _storage.delete(key:_keyName);final temp=await getTemporaryDirectory();for(final f in temp.listSync().whereType<File>().where((f)=>f.path.endsWith('.pdf'))){try{f.deleteSync();}catch(_){}}}
}
