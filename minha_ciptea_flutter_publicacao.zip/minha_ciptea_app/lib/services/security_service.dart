import 'package:local_auth/local_auth.dart';
import 'package:screen_protector/screen_protector.dart';
class SecurityService {
 final _auth=LocalAuthentication();
 Future<bool> authenticate() async {try{if(!await _auth.isDeviceSupported())return true;return await _auth.authenticate(localizedReason:'Confirme sua identidade para abrir a CIPTEA',options:const AuthenticationOptions(biometricOnly:false,stickyAuth:true));}catch(_){return false;}}
 Future<void> protect(bool enabled)=>enabled?ScreenProtector.protectDataLeakageOn():ScreenProtector.protectDataLeakageOff();
}
