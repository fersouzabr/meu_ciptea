#!/usr/bin/env bash
set -euo pipefail
command -v flutter >/dev/null || { echo 'Flutter nao encontrado no PATH.'; exit 1; }
flutter create . --platforms=android --org br.com.minhaciptea --project-name minha_ciptea
flutter pub get
flutter analyze
flutter test
flutter build appbundle --release
printf '\nAAB: build/app/outputs/bundle/release/app-release.aab\n'
